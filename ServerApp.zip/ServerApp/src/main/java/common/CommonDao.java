package common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;

public class CommonDao {
	
	 private static final String jdbcHosting = "jdbc:mysql://localhost:3306/SERVER_ALLOCATION";
	    private static final String user="Gokul";
	    private static final String pass="";
	    
	
	public HashMap<String,Object> validate(String s){ 
		
		HashMap<String,Object> hMap=new HashMap<>();
	try {
		Class.forName("com.mysql.jdbc.Driver");
		
try(
		Connection con=DriverManager.getConnection(jdbcHosting,user,pass);
		PreparedStatement pStatement=con.prepareStatement("select * from SERVER_MANAGEMENT where C_EMAIL=?");
	) {
	
	
	pStatement.setString(1,s);
	
	try(ResultSet rSet=pStatement.executeQuery();) {
		
		while(rSet.next()) {
			
    		hMap.put("id", rSet.getInt(1));
    		hMap.put("name", rSet.getString(2));
    		hMap.put("pass", rSet.getString(3));
    		hMap.put("email", rSet.getString(4));
    		hMap.put("utype", rSet.getInt(5));
    		
    		}
	}catch(Exception e){
		
	}
}catch (Exception e) {
	
}
	}catch (Exception e) {
		
	}
return hMap;
	}
}
