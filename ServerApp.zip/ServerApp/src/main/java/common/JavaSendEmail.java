package common;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

public class JavaSendEmail {
    public static void sendMail(String recepient,String sub,String text){
        System.out.println("Preparing to send Email");

        Properties properties=new Properties();
        properties.put("mail.smtp.auth","true");
        properties.put("mail.smtp.starttls.enable","true");
        properties.put("mail.smtp.host","smtp.zoho.com");
        properties.put("mail.smtp.port","587");

        final String username="gokulnath.ks@zohocorp.com";
        final String password="BdWhegdU1adj";

        Session session=Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username,password);
            }
        });

        Message message=prepareMessage(session,username,recepient,sub,text);
        try{
            Transport.send(message);
        }catch (Exception e){
            e.printStackTrace();
        }
        System.out.println("Email sent Successfully to"+recepient);
    }
    private static Message prepareMessage(Session session,String username,String recepient,String sub,String text){
        Message message=new MimeMessage(session);
        try{
            message.setFrom(new InternetAddress(username));
            message.setRecipient(Message.RecipientType.TO,new InternetAddress(recepient));
            message.setSubject(sub);
            message.setText(text);
        }catch (Exception e){
            e.printStackTrace();
        }
        return message;
    }
}
