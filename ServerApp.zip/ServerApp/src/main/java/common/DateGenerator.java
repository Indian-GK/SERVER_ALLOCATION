package common;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateGenerator {
	
	public String dataPrep() {
		DateFormat formatter = new SimpleDateFormat("dd/MM/yy");
	      Calendar obj = Calendar.getInstance();
	      String str = formatter.format(obj.getTime());
	      
	      return str;
	}
	public String timePrep() {
	DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
	Date date = new Date();
	String ans=dateFormat.format(date);
	
	return ans;
	}
}
