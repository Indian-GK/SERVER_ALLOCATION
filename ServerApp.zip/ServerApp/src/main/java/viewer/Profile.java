package viewer;

public class Profile {
	
	private int id,type,req,resp_num,rid;
	

	private String reqDate,respDate,resp;
	
	public Profile(int id,int type,String reqDate,int req,int resp_num,String resp,String respDate) {
		
		this.id=id;
		this.type=type;
		this.reqDate=reqDate;
		this.req=req;
		this.resp_num=resp_num;
		this.resp=resp;	
		this.respDate=respDate;
	}
	
	
    public Profile(int id,int type,String reqDate,int req,int resp_num,String resp,String respDate,int rid) {
		this.id=id;
		this.type=type;
		this.reqDate=reqDate;
		this.req=req;
		this.resp_num=resp_num;
		this.resp=resp;
		this.respDate=respDate;
		this.rid=rid;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getReq() {
		return req;
	}
	public void setReq(int req) {
		this.req = req;
	}
	public int getRespNum() {
		return resp_num;
	}
	public void setRespNum(int resp_num) {
		this.resp_num = resp_num;
	}
	public String getResp() {
		return resp;
	}
	public void setResp(String resp) {
		this.resp = resp;
	}
	public String getReqDate() {
		return reqDate;
	}
	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}
	public String getRespDate() {
		return respDate;
	}
	public void setRespDate(String respDate) {
		this.respDate = respDate;
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	
	@Override
	public String toString() {
		return "profile{" +"id=" +id +", type=" +type +", request_Date=" +reqDate +",req =" +req+", reponsed="+resp_num+", reponse="+resp+", reponsed_Date="+respDate+", r_id="+rid+'}';
	}
	
}
