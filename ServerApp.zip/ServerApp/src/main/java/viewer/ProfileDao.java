package viewer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import common.DateGenerator;


public class ProfileDao {
	Connection con;

    public ProfileDao(Connection con) {
        this.con = con;
    }
    
    public boolean addProfile(Profile p){
        boolean test = false;
        
        String query =  "INSERT INTO RECORDS(C_ID,USER_TYPE,REQ_DATE,REQUEST,RESP_NUM,RESPONSE,APP_DATE) values(?,?,?,?,?,?,?)";

        try(
            PreparedStatement pst = this.con.prepareStatement(query);){
        	
            pst.setInt(1, p.getId());
            pst.setInt(2, p.getType());
            pst.setString(3,p.getReqDate());
            pst.setInt(4, p.getReq());
            pst.setInt(5,p.getRespNum());
            pst.setString(6, p.getResp());
            pst.setString(7, p.getRespDate());
            
            pst.executeUpdate();
            test= true;

        }catch(Exception e){
            e.printStackTrace();
        }finally {
	    	try {
	    		con.close();
	    	} catch (Exception e) {
	    		
	    	}
	    } 
        return test;
    }
    
    
 public List<Profile> getAllProfile(){
    	
        List<Profile> ans = new ArrayList<>();
        String query = "select * from RECORDS";
        
        try(
            PreparedStatement pt = this.con.prepareStatement(query);){
            ResultSet rs = pt.executeQuery();
            
            while(rs.next()){
            	
                int id = rs.getInt("C_ID");
                int type = rs.getInt("USER_TYPE");
                String reqDate = rs.getString("REQ_DATE");
                int req = rs.getInt("REQUEST");
                int num=rs.getInt("RESP_NUM");
                String resp = rs.getString("RESPONSE");
                String respDate=rs.getString("APP_DATE");
                int rid=rs.getInt("R_ID");
                
                Profile row = new Profile(id,type,reqDate,req,num,resp,respDate,rid);
                ans.add(row);
            }
            
        }catch(Exception e){
            e.printStackTrace();
        } finally {
        	try {
        		con.close();
        	} catch (Exception e) {
        		
        	}
        }  
        return ans;
    }
 
 
 public void editProfileRejectInfo(String res,String date,int id,int rid){
     	 
    String query = "update RECORDS set RESPONSE=?,APP_DATE=? where C_ID=? AND R_ID=?";

    try(
        PreparedStatement pt = this.con.prepareStatement(query);){
        pt.setString(1, res);
        pt.setString(2,date);
        pt.setInt(3,id);
        pt.setInt(4,rid);
               
        pt.executeUpdate();
        
    }catch(Exception ex){
        ex.printStackTrace();
    } finally {
    	try {
    		con.close();
    	} catch (Exception e) {
    		
    	}
    }  
}
 
 
 public void changeResponseStatus(int respNum,String res,int rid){
	 
	    String query = "update RECORDS set RESP_NUM=?,RESPONSE=?,APP_DATE=? where R_ID=?";

	    try(
	        PreparedStatement pt = this.con.prepareStatement(query);){
	    	
	    	pt.setInt(1,respNum);
	        pt.setString(2, res);
	        DateGenerator dg=new DateGenerator();
	        pt.setString(3,dg.dataPrep());
	        pt.setInt(4,rid);
	               
	        pt.executeUpdate();
	        
	    }catch(Exception ex){
	        ex.printStackTrace();
	    } finally {
	    	try {
	    		con.close();
	    	} catch (Exception e) {
	    		
	    	}
	    }  
	}
 
 public List<Profile> getSortedProfile(String s){
 	
     List<Profile> ans = new ArrayList<>();
     String query = "select * from RECORDS where RESPONSE=?";
     
     try(
         PreparedStatement pt = this.con.prepareStatement(query);){
    	 pt.setString(1,s);
         ResultSet rs = pt.executeQuery();
         
         while(rs.next()){
         	
             int id = rs.getInt("C_ID");
             int type = rs.getInt("USER_TYPE");
             String reqDate = rs.getString("REQ_DATE");
             int req = rs.getInt("REQUEST");
             int num=rs.getInt("RESP_NUM");
             String resp = rs.getString("RESPONSE");
             String respDate=rs.getString("APP_DATE");
             int rid=rs.getInt("R_ID");
             
             Profile row = new Profile(id,type,reqDate,req,num,resp,respDate,rid);
             ans.add(row);
         }
         
     }catch(Exception e){
         e.printStackTrace();
     } finally {
     	try {
     		con.close();
     	} catch (Exception e) {
     		
     	}
     }  
     return ans;
 }
 
 public List<Profile> getAllProfileStack(){
 	
     List<Profile> ans = new ArrayList<>();
     String query = "select * from RECORDS ORDER BY REQ_DATE DESC";
     
     try(
         PreparedStatement pt = this.con.prepareStatement(query);){
         ResultSet rs = pt.executeQuery();
         
         while(rs.next()){
         	
             int id = rs.getInt("C_ID");
             int type = rs.getInt("USER_TYPE");
             String reqDate = rs.getString("REQ_DATE");
             int req = rs.getInt("REQUEST");
             int num=rs.getInt("RESP_NUM");
             String resp = rs.getString("RESPONSE");
             String respDate=rs.getString("APP_DATE");
             int rid=rs.getInt("R_ID");
             
             Profile row = new Profile(id,type,reqDate,req,num,resp,respDate,rid);
             ans.add(row);
         }
         
     }catch(Exception e){
         e.printStackTrace();
     } finally {
     	try {
     		con.close();
     	} catch (Exception e) {
     		
     	}
     }  
     return ans;
 }
 
 public List<Profile> getAllIdOfProfile(int cid){
	 	
     List<Profile> ans = new Stack<>();
     String query = "select * from RECORDS WHERE C_ID=?";
     
     try(
         PreparedStatement pt = this.con.prepareStatement(query);){
    	 pt.setInt(1,cid);
         ResultSet rs = pt.executeQuery();
         
         while(rs.next()){
         	
             int id = rs.getInt("C_ID");
             int type = rs.getInt("USER_TYPE");
             String reqDate = rs.getString("REQ_DATE");
             int req = rs.getInt("REQUEST");
             int num=rs.getInt("RESP_NUM");
             String resp = rs.getString("RESPONSE");
             String respDate=rs.getString("APP_DATE");
             int rid=rs.getInt("R_ID");
             
             Profile row = new Profile(id,type,reqDate,req,num,resp,respDate,rid);
             ans.add(row);
         }
         
     }catch(Exception e){
         e.printStackTrace();
     } finally {
     	try {
     		con.close();
     	} catch (Exception e) {
     		
     	}
     }  
     return ans;
 }

 
 
 public List<Profile> getSortedUserProfile(String s,int n){
	 	
     List<Profile> ans = new ArrayList<>();
     String query = "select * from RECORDS where RESPONSE=? AND C_ID=?";
     
     try(
         PreparedStatement pt = this.con.prepareStatement(query);){
    	 pt.setString(1,s);
    	 pt.setInt(2,n);
         ResultSet rs = pt.executeQuery();
         
         while(rs.next()){
         	
             int id = rs.getInt("C_ID");
             int type = rs.getInt("USER_TYPE");
             String reqDate = rs.getString("REQ_DATE");
             int req = rs.getInt("REQUEST");
             int num=rs.getInt("RESP_NUM");
             String resp = rs.getString("RESPONSE");
             String respDate=rs.getString("APP_DATE");
             int rid=rs.getInt("R_ID");
             
             Profile row = new Profile(id,type,reqDate,req,num,resp,respDate,rid);
             ans.add(row);
         }
         
     }catch(Exception e){
         e.printStackTrace();
     } finally {
     	try {
     		con.close();
     	} catch (Exception e) {
     		
     	}
     }  
     return ans;
 }
 
 
 public Stack<Profile> getAllLatestProfileUser(int n){
	 	
     Stack<Profile> ans = new Stack<>();
     String query = "select * from RECORDS where C_ID=? ORDER BY REQ_DATE DESC";
     
     try(
         PreparedStatement pt = this.con.prepareStatement(query);){
    	 pt.setInt(1,n);
         ResultSet rs = pt.executeQuery();
         
         while(rs.next()){
         	
             int id = rs.getInt("C_ID");
             int type = rs.getInt("USER_TYPE");
             String reqDate = rs.getString("REQ_DATE");
             int req = rs.getInt("REQUEST");
             int num=rs.getInt("RESP_NUM");
             String resp = rs.getString("RESPONSE");
             String respDate=rs.getString("APP_DATE");
             int rid=rs.getInt("R_ID");
             
             Profile row = new Profile(id,type,reqDate,req,num,resp,respDate,rid);
             ans.add(row);
         }
         
     }catch(Exception e){
         e.printStackTrace();
     } finally {
     	try {
     		con.close();
     	} catch (Exception e) {
     		
     	}
     }  
     return ans;
 }

}
