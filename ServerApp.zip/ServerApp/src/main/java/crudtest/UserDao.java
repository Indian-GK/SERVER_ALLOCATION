package crudtest;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
    Connection con;

    public UserDao(Connection con) {
        this.con = con;
    }
    
    
    public boolean addUser(User u){
        boolean test = false;
        
        String query =  "insert into SERVER_MANAGEMENT(C_NAME,C_PASSWORD,C_EMAIL,USER_ID) values(?,?,?,?)";

        try(
            PreparedStatement pst = this.con.prepareStatement(query);){
        	
            pst.setString(1, u.getName());
            pst.setString(2, u.getPassword());
            pst.setString(3, u.getEmail());
            pst.setInt(4, u.getUserid());
            
            pst.executeUpdate();
            test= true;

        }catch(Exception e){
            e.printStackTrace();
        } finally {
        	try {
        		con.close();
        	} catch (Exception e) {
        		
        	}
        }  
        return test;
    }
    
    
    public List<User> getAllBooks(){
        List<User> ans = new ArrayList<>();
        String query = "select * from SERVER_MANAGEMENT";
        
        try(
            PreparedStatement pt = this.con.prepareStatement(query);){
            ResultSet rs = pt.executeQuery();
            
            while(rs.next()){
                int id = rs.getInt("C_ID");
                String name = rs.getString("C_NAME");
                String pass = rs.getString("C_PASSWORD");
                String mail = rs.getString("C_EMAIL");
                int user = rs.getInt("USER_ID");
                
                User row = new User(id,name,pass,mail,user);
                ans.add(row);
            }
            
        }catch(Exception e){
            e.printStackTrace();
        } finally {
        	try {
        		con.close();
        	} catch (Exception e) {
        		
        	}
        }  
        return ans;
    }
    
    
    public boolean editBookInfo(User u){
        
    	 boolean test = false;
    	 
        String query = "update SERVER_MANAGEMENT set C_NAME=?, C_PASSWORD=?, C_EMAIL=?, USER_ID=? where C_ID=?";

        try(
            PreparedStatement pt = this.con.prepareStatement(query);){
            pt.setString(1, u.getName());
            pt.setString(2, u.getPassword());
            pt.setString(3, u.getEmail());
            pt.setInt(4, u.getUserid());
            pt.setInt(5, u.getId());
            
            pt.executeUpdate();
            test= true;
        }catch(Exception ex){
            ex.printStackTrace();
        } finally {
        	try {
        		con.close();
        	} catch (Exception e) {
        		
        	}
        }  
		return test;
        
    }
    

    public User getSingleUser(int id){
        User bk = null;
        
        String query = "select * from SERVER_MANAGEMENT where C_ID=? ";
        
        try(  
            PreparedStatement pt = this.con.prepareStatement(query);){
            pt.setInt(1, id);
            ResultSet rs= pt.executeQuery();
            
            while(rs.next()){
                int cid = rs.getInt("C_ID");
                String name = rs.getString("C_NAME");
                String pass = rs.getString("C_PASSWORD");
                String mail = rs.getString("C_EMAIL");
                int userid  = rs.getInt("USER_ID");
                bk = new User(cid,name,pass,mail,userid);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        } finally {
        	try {
        		con.close();
        	} catch (Exception e) {
        		
        	}
        }  
        return bk;
    }
      
    
    public void deleteBook(int id){
    	String query= "delete from SERVER_MANAGEMENT where C_ID=?";
        try(
           PreparedStatement pt = this.con.prepareStatement(query);){
           pt.setInt(1, id);
           pt.execute();
            
        }catch(Exception ex){
            ex.printStackTrace();;
        } finally {
        	try {
        		con.close();
        	} catch (Exception e) {
        		
        	}
        }  
    }
    
    public List<User> getSearch(String s){
        List<User> ans = new ArrayList<>();
        String query = "select * from SERVER_MANAGEMENT where C_NAME LIKE "+"'"+s+"%'";
        
        try(
            PreparedStatement pt = this.con.prepareStatement(query);){
            ResultSet rs = pt.executeQuery();
            
            while(rs.next()){
                int id = rs.getInt("C_ID");
                String name = rs.getString("C_NAME");
                String pass = rs.getString("C_PASSWORD");
                String mail = rs.getString("C_EMAIL");
                int user = rs.getInt("USER_ID");
                
                User row = new User(id,name,pass,mail,user);
                ans.add(row);
            }
            
        }catch(Exception e){
            e.printStackTrace();
        } finally {
        	try {
        		con.close();
        	} catch (Exception e) {
        		
        	}
        }  
        return ans;
    }
}


