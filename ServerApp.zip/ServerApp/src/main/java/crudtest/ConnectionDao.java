
package crudtest;
import java.sql.*;

public class ConnectionDao {
    private static Connection con;

    public static Connection getCon() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/SERVER_ALLOCATION","Gokul","");
        }catch (Exception ex) {
            ex.printStackTrace();
        } 
        return con;
    }
}
