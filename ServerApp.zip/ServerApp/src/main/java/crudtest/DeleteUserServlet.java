package crudtest;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/DeleteUserServlet")
public class DeleteUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		
		HttpSession session2 =request.getSession();
		   if(session2.getAttribute("Auth")!=null&&session2.getAttribute("Auth").equals(1)){
			   
		 int bid = Integer.parseInt(request.getParameter("id"));
         
         try{
             UserDao bkd = new UserDao(ConnectionDao.getCon());
             bkd.deleteBook(bid);
             response.sendRedirect("index.jsp");
         }catch(Exception e){
             e.printStackTrace();
         }
		   }else {
			   RequestDispatcher rd=request.getRequestDispatcher("ErrorPage.html");
			   	rd.forward(request, response);  
		   }
	}

}
