package crudtest;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/EditUserServlet")
public class EditUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		
		HttpSession session2 =request.getSession();
		   if(session2.getAttribute("Auth")!=null&&session2.getAttribute("Auth").equals(1)){

		int id=Integer.parseInt(request.getParameter("id"));
        String Name = request.getParameter("Name");
        String Pass = request.getParameter("Pass");
        String Email = request.getParameter("Mail");          
        int utype = Integer.parseInt(request.getParameter("category"));
        User book = new User(id,Name,Pass,Email,utype);
        try{
            UserDao bkdao = new UserDao(ConnectionDao.getCon());
            
            if(bkdao.editBookInfo(book)){
                response.sendRedirect("index.jsp");
            }else{
            	PrintWriter out=response.getWriter();
                out.print("wrong cre3dential");
                out.close();
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
		   }else {
			   response.sendRedirect("ErrorPage.html");
		   }

	}

}
