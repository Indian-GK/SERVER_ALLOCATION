package resources;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.DateGenerator;
import crudtest.ConnectionDao;
import logics.LogicDao;
import viewer.Profile;

@WebServlet("/AddResourceServlet")
public class AddResourceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		
		String name=(String)request.getParameter("Name");
		int value=Integer.parseInt(request.getParameter("value"));
		int cap=value;
		
			PrintWriter out=response.getWriter();
		
		if(name.equals(null)||value==0) {
			out.print("invalid input");
		}else {
		
		DateGenerator dg=new DateGenerator();
		String date=dg.dataPrep();
		
		Resource resource=new Resource(name,cap,value,1,date);
		try {
			ResourceDao rDao= new ResourceDao(ConnectionDao.getCon());
			if(rDao.addResource(resource)) {
				LogicDao obj=new LogicDao();
				try{
				List<Profile> list=obj.getPartiallyFilled();

				if(list!=null && obj.totalAvailable()>0){
					
					String linker="./SuperApproveOperation?id="+list.get(0).getRid()+"&&req="+list.get(0).getReq()+"&&resp="+list.get(0).getResp()+"&&resp_num="+list.get(0).getRespNum();
				RequestDispatcher rd=request.getRequestDispatcher(linker);
					rd.forward(request, response);
				}else {
					response.sendRedirect("resourceview.jsp");
				}
				}catch(Exception e){
					response.sendRedirect("resourceview.jsp");
				}
				
			}
		} catch (SQLException e) {
			out.print(e);
		}
		
	}
		
		out.close();
	}

}
