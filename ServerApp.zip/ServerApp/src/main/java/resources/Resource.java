package resources;

public class Resource {
	
	private int value,userid,resourceId,cap;
	private String name,date;
	
	public Resource(String name,int cap,int value,int userid,String date) {
		this.name=name;
		this.cap=cap;
		this.value=value;
		this.userid=userid;
		this.date=date;
	}
	public Resource(String name,int cap,int value,int userid,String date,int resourceId) {
		this.name=name;
		this.cap=cap;
		this.value=value;
		this.userid=userid;
		this.date=date;
		this.resourceId=resourceId;
	}
	
	
	public int getCap() {
		return cap;
	}
	public void setCap(int cap) {
		this.cap = cap;
	}
	public int getResourceId() {
		return resourceId;
	}
	public void setResourceId(int resourceId) {
		this.resourceId = resourceId;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
}
