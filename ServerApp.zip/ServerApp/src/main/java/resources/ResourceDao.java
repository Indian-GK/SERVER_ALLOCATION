package resources;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import common.CommonDao;
import common.DateGenerator;

public class ResourceDao {
	Connection con;

    public ResourceDao(Connection con) {
        this.con = con;
    }
    
    
    public boolean addResource(Resource r){
        boolean test = false;
        
        String query =  "INSERT INTO RESOURCES(R_NAME,R_CAPACITY,R_VALUE,USER_ID,INC_DATE) values(?,?,?,?,?)";

        try(
            PreparedStatement pst = this.con.prepareStatement(query);){
        	
            pst.setString(1,r.getName());
            pst.setInt(2,r.getCap());
            pst.setInt(3,r.getValue());
            pst.setInt(4, r.getUserid());
            pst.setString(5,r.getDate());
            
            
            pst.executeUpdate();
            test= true;

        }catch(Exception e){
            e.printStackTrace();
        }finally {
	    	try {
	    		con.close();
	    	} catch (Exception e) {
	    		
	    	}
	    } 
        return test;
    }
    
    
 public List<Resource> getAllResource(){
    	
        List<Resource> ans = new ArrayList<Resource>();
        String query = "select * from RESOURCES";
        
        try(
            PreparedStatement pt = this.con.prepareStatement(query);){
            ResultSet rs = pt.executeQuery();
            
            while(rs.next()){
            	
                String name=rs.getString("R_NAME");
                int cap=rs.getInt("R_CAPACITY");
                int value=rs.getInt("R_VALUE");
                int user=rs.getInt("USER_ID");
                String date=rs.getString("INC_DATE");
                
                Resource row = new Resource(name,cap,value,user,date);
                ans.add(row);
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }finally {
	    	try {
	    		con.close();
	    	} catch (Exception e) {
	    		
	    	}
	    } 
        return ans;
    }
 
 public boolean updateForResource(String key,int value){
	 boolean flag=false;
	    String query = "update RESOURCES set R_VALUE=? where R_NAME=?";

	    try(
	        PreparedStatement pt = this.con.prepareStatement(query);){
	    	flag=true;
	    	
	    	pt.setInt(1,value);    	
	        pt.setString(2,key);
	        
	               
	        pt.executeUpdate();
	        
	    }catch(Exception ex){
	        ex.printStackTrace();
	    } finally {
	    	try {
	    		con.close();
	    	} catch (Exception e) {
	    		
	    	}
	    } 
	    return flag;
	}
    
}
