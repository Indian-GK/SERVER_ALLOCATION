package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import common.*;


@WebServlet("/LoginApp")
public class LoginApp extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		int val=0;
		try {
		Cookie[] ck=request.getCookies();
		for(Cookie c:ck) {
			if(c.getName().equals("AuthCook")&&!c.getValue().equals("")) {
				val=Integer.parseInt(c.getValue());
				break;
			}	
		}	
		}catch (Exception e) {
			
		}
		
		if(val==0) {
		
		String mailString=(String)request.getParameter("mail");
		String passEntry=(String)request.getParameter("xpass");
		
		if(mailString.equals(null)||passEntry.equals(null)) 
		{
			out.print("null inputs");
		}else 
		{
			
		try {
				
		CommonDao obj =new CommonDao();
	    HashMap<String,Object> hMap=obj.validate(mailString);
	    
	    
	    if(hMap.get("email").equals(mailString)&&
	    		hMap.get("pass").equals(passEntry)
				&&hMap.get("email")!=null&&hMap.get("pass")!=null) 
	    {
	    	HttpSession session=request.getSession();
	    	session.setAttribute("Auth",hMap.get("utype"));
	    	
	    	Cookie cookie=new Cookie("AuthCook",hMap.get("utype").toString());
	    	cookie.setMaxAge(86400);
	    	response.addCookie(cookie);
	    	
			if(hMap.get("utype").equals(1)) 
			{
				response.sendRedirect("index.jsp");
	    	   	
			}else if(hMap.get("utype").equals(2)) 
			{
				response.sendRedirect("adminview.jsp");
			}else if(hMap.get("utype").equals(3))
			{
					
				session.setAttribute("u_id",hMap.get("id"));
				session.setAttribute("u_type",hMap.get("utype"));
				session.setAttribute("mailid",hMap.get("email"));
				
				response.sendRedirect("userdetails.jsp");
	   
			}
		}else
		{
			response.sendRedirect("ErrorPage.html");
		}
	    }catch(Exception e){
	    	response.sendRedirect("ErrorPage.html");
	  }
	}
		}else {
	    	
			if(val==1) {
				RequestDispatcher rd=request.getRequestDispatcher("index.jsp");    
	    	   	rd.forward(request, response);
			}else if(val==2) {
				RequestDispatcher rd=request.getRequestDispatcher("adminview.jsp");    
	    	   	rd.forward(request, response);
			}else if(val==3) {
				RequestDispatcher rd=request.getRequestDispatcher("userdetails.jsp");    
	    	   	rd.forward(request, response);
			}
		}
  }
}
