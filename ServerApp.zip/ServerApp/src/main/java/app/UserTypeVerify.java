package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.*;

@WebServlet("/UserTypeVerify")
public class UserTypeVerify extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		
		int val=0;
		try {
		Cookie[] ck=request.getCookies();
		for(Cookie c:ck) {
			if(c.getName().equals("AuthCook")&&!c.getValue().equals("")) {
				val=Integer.parseInt(c.getValue());
				break;
			}	
		}	
		}catch (Exception e) {
			
		}
		
		if(val==0) {
		
		PrintWriter out=response.getWriter();
		
		HttpSession session=request.getSession();
		String str=(String)session.getAttribute("mailid");
		
		if(str!=null) {
		
		try {
			CommonDao obj =new CommonDao();
			HashMap<String,Object> hMap=obj.validate(str);
			
			Object u=hMap.get("utype");
			session.setAttribute("Auth","success");
			
			Cookie cookie=new Cookie("AuthCook",hMap.get("utype").toString());
	    	cookie.setMaxAge(86400);
	    	response.addCookie(cookie);
			
			if(u.equals(1)) {
				
				response.sendRedirect("index.jsp");
			}else if(u.equals(2)) {
				
				response.sendRedirect("adminview.jsp");
			}else if(u.equals(3)) {
				
			session.setAttribute("u_id", hMap.get("id"));
			session.setAttribute("u_type",u);
			
			response.sendRedirect("userdetails.jsp");
			}
		}catch (Exception e) {
			out.print("you are not found");
		}
		}else {
			response.sendRedirect("ErrorPage.html");
		}
		}else {
			if(val==1) {
				response.sendRedirect("index.jsp");
			}else if(val==2) {
				response.sendRedirect("adminview.jsp");
			}else if(val==3) {
				response.sendRedirect("userdetails.jsp");
			}
		}
	}

}
