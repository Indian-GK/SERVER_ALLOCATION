package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.JavaSendEmail;


@WebServlet("/ForgotPassword")
public class ForgotPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		
		PrintWriter out=response.getWriter();
		
		String passString=getRandomNumberString();
		
		String reqString=request.getParameter("mail");
		
		if(reqString.contains("@zohocorp.com")&&reqString!=null) {
		
				try {
					common.JavaSendEmail.sendMail(reqString,"[CONFIRMATION MAIL]","Your OTP FOR VERIFICATION IS :"+passString);
					
					HttpSession session=request.getSession();
					session.setAttribute("req",passString);
					session.setAttribute("mailid", reqString);
					response.sendRedirect("otp.html");
			
		} catch (Exception e1) {
		    out.println("email doesn't found"); 
		}
	}else {
		out.print("not found try again!");
	}
		out.close();
		
	}
public String getRandomNumberString() {
    
    Random rnd = new Random();
    int number = rnd.nextInt(999999);

    return String.format("%06d", number);
}

}
