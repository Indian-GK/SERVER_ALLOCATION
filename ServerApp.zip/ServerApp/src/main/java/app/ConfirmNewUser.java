package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.CommonDao;

/**
 * Servlet implementation class ConfirmNewUser
 */
@WebServlet("/ConfirmNewUser")
public class ConfirmNewUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final String jdbcHosting = "jdbc:mysql://localhost:3306/SERVER_ALLOCATION";
    private static final String user="Gokul";
    private static final String pass="";
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		
		int val=0;
		try {
		Cookie[] ck=request.getCookies();
		for(Cookie c:ck) {
			if(c.getName().equals("AuthCook")&&!c.getValue().equals("")) {
				val=Integer.parseInt(c.getValue());
				break;
			}	
		}	
		}catch (Exception e) {
			
		}
		
		if(val==0) {
		
		boolean sign=false;
		boolean go=false;
		HttpSession session=request.getSession();
		
		PrintWriter out=response.getWriter();
		
		String uNameString=(String)session.getAttribute("name");
		String mailString=(String)session.getAttribute("mailid");
		String passEntry=(String)session.getAttribute("pass");
		
		String matcher=(String)session.getAttribute("match");
		
		if(matcher.equals("yes")) {
			sign=true;
		}
		
		if(sign) {
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
	    try(
	    		Connection con=DriverManager.getConnection(jdbcHosting,user,pass);
	    		PreparedStatement pStatement=con.prepareStatement("select C_EMAIL from SERVER_MANAGEMENT");
	    	) {
	    	
             boolean flag=true;
             ResultSet rSet=pStatement.executeQuery();
    		
    		while(rSet.next()) {
    			
    		String valString=rSet.getString(1);
    		if(valString.equals(mailString)) {
    			flag=false;
    			break;
    		}
    		
    	}
    		
    		try (PreparedStatement ps=con.prepareStatement("INSERT INTO SERVER_MANAGEMENT(C_NAME,C_PASSWORD,C_EMAIL,USER_ID)"
					+ " VALUES(?,?,?,?)");){
	    		
	    		if(flag) {
	        	    
	    			ps.setString(1,uNameString);
	    			ps.setString(2, passEntry);
	    			ps.setString(3,mailString);
	    			ps.setInt(4,3);
	    			
	    			ps.executeUpdate();
	    			
	    			CommonDao objCommonDao=new CommonDao();
	    			HashMap<String,Object> hMap=objCommonDao.validate(mailString);
	    			
	    			Cookie cookie=new Cookie("AuthCook",hMap.get("utype").toString());
	    	    	cookie.setMaxAge(86400);
	    	    	response.addCookie(cookie);
	    			
	    				response.sendRedirect("userdetails.jsp");
	    	    	   			 			
	    		}else {
	    			out.println("already you are signed up!");
	    		}	
			}catch (Exception e) {
				out.println("connection issues");
		   }
		    }catch (Exception e) {
		    out.print(e);				
		   } 
	       }catch (Exception e) {
		    out.print(e);
           }
		}else {
				out.print("you given a wrong value please try again!");
			}
		
		out.close();
	}else {
		if(val==1) {
			response.sendRedirect("index.jsp");
		}else if(val==2) {
			response.sendRedirect("adminview.jsp");
		}else if(val==3) {
			response.sendRedirect("userdetails.jsp");
		}
	}
	}

}
