package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/NewUser")
public class NewUser extends HttpServlet {
	    
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		
		PrintWriter out=response.getWriter();
		
		String uNameString=(String)request.getParameter("uname");
		String mailString=(String)request.getParameter("mail");
		String passEntry=(String)request.getParameter("xpass");
		
		
		if(mailString.equals(null)||passEntry.equals(null)||uNameString.equals(null)) {
			out.println("new user1 null");
		}else {
			try {
				ForgotPassword obj=new ForgotPassword();
				String passString=obj.getRandomNumberString();
			  common.JavaSendEmail.sendMail(mailString,"[CONFIRMATION MAIL]","Your OTP FOR VERIFICATION IS :"+passString);
			  
			  HttpSession session=request.getSession();
			  
				session.setAttribute("signup",passString);
				session.setAttribute("name",uNameString);
				session.setAttribute("mailid",mailString);
				session.setAttribute("pass", passEntry);
				response.sendRedirect("otp.html");
				
			}catch(Exception e) {
				out.println("newUser-2 "+e);
			}
    	out.close();
	}
  }
}
