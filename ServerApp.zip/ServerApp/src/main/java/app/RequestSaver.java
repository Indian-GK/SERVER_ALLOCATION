package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import viewer.*;
import common.*;
import crudtest.ConnectionDao;



@WebServlet("/RequestSaver")
public class RequestSaver extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		
		 HttpSession session2 =request.getSession();
		   if(session2.getAttribute("Auth")!=null&&session2.getAttribute("Auth").equals(3)){
		
		String numString=request.getParameter("input");
		
		DateGenerator dg=new DateGenerator();
		String str=dg.dataPrep();
	      
		if(numString.equals("0")||numString.equals(".")||numString.equals(null)) {
			RequestDispatcher rd=request.getRequestDispatcher("ErrorPage.html");
    	   	rd.forward(request, response);
		}else {
			
			int num=Integer.parseInt(numString);//req
			
			PrintWriter out= response.getWriter();
			HttpSession session =request.getSession();
			
			Object idString=session.getAttribute("u_id");
			Object typeString=session.getAttribute("u_type");
			String mailString=(String)session.getAttribute("mailid");
			
			if(idString!=null&&typeString!=null)  {
				
				int id=(int)idString;
				int type=(int)typeString;
				
				Profile profile=new Profile(id,type,str,num,0,"PENDING", null);
				
				try{
		            ProfileDao dao = new ProfileDao(ConnectionDao.getCon());
		            if(dao.addProfile(profile)){
						RequestDispatcher rd=request.getRequestDispatcher("userdetails.jsp");    
			    	   	rd.forward(request, response);
		            }else{	
		                out.print("wrong cre3dential");
		            }
			}catch (Exception e) {
				
			}
			}else if(mailString!=null){
							
				try {
					
				CommonDao obj2=new CommonDao();
			HashMap<String,Object> hp= obj2.validate(mailString);
			
			int id=(int) hp.get("id");
			int type=(int)hp.get("utype");
			
			Profile profile=new Profile(id,type,str,num,0,"PENDING", null);
			
			try{
	            ProfileDao dao = new ProfileDao(ConnectionDao.getCon());
	            if(dao.addProfile(profile)){
	            	
	            	out.print("send successfully");
	            }else{	
	                out.print("wrong cre3dential");
	            }
	            
		}catch (Exception e) {
			out.print(e);
		}
			
				}catch (Exception e) {
					
				}
			}else {
				response.sendRedirect("ErrorPage.html");
			}
			out.close();
			
		}
		   }else {
			   RequestDispatcher rd=request.getRequestDispatcher("ErrorPage.html");
	    	   	rd.forward(request, response);
		   }
	}

}
