package logics;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import common.DateGenerator;
import crudtest.ConnectionDao;
import viewer.Profile;

public class NotifyTable {
	
	public boolean insertNotification() {
		
		boolean test =false;
		String query="INSERT INTO RESOURCE_UPDATES(M_DATE,M_TIME,MSG) VALUES(?,?,?)";
		try(Connection con=ConnectionDao.getCon()){
			try(PreparedStatement ps=con.prepareStatement(query)){
				
				DateGenerator dg=new DateGenerator();
				String msg="PLEASE REGISTER TO NEW SERVERS "
						+ "BECAUSE THE LOAD WENT TO BELOW 10%";
				String dateString=dg.dataPrep();
				String timeString=dg.timePrep();
				
				ps.setString(1,dateString);
				ps.setString(2,timeString);
				
				
				ps.setString(3, msg);
				ps.executeUpdate();
				test=true;
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return test;
		
	}
	
public List<Notify> getAllNotify(){
    	
        List<Notify> ans = new ArrayList<>();
        String query = "select * from RESOURCE_UPDATES";
        
        
        try(Connection con=ConnectionDao.getCon()){
        try(
            PreparedStatement pt = con.prepareStatement(query);){
            ResultSet rs = pt.executeQuery();
            
            while(rs.next()){
            	
                int id = rs.getInt("M_ID");
                String date=rs.getString("M_DATE");
                String time=rs.getString("M_TIME");
                String msg=rs.getString("MSG");
                
                Notify row = new Notify(id,date,time,msg);
                ans.add(row);
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        	} catch (Exception e) {
        		
        	} 
        return ans;
    }

public List<Notify> getAllLatestNotify(){
	
    List<Notify> ans = new ArrayList<>();
    String query = "select * from RESOURCE_UPDATES ORDER BY M_ID DESC";
    
    
    try(Connection con=ConnectionDao.getCon()){
    try(
        PreparedStatement pt = con.prepareStatement(query);){
        ResultSet rs = pt.executeQuery();
        
        while(rs.next()){
        	
            int id = rs.getInt("M_ID");
            String date=rs.getString("M_DATE");
            String time=rs.getString("M_TIME");
            String msg=rs.getString("MSG");
            
            Notify row = new Notify(id,date,time,msg);
            ans.add(row);
        }
        
    }catch(Exception e){
        e.printStackTrace();
    }
    	} catch (Exception e) {
    		
    	} 
    return ans;
}
}
