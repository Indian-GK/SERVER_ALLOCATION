package logics;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import crudtest.ConnectionDao;
import resources.ResourceDao;
import viewer.ProfileDao;

/**
 * Servlet implementation class SuperApproveOperation
 */
@WebServlet("/SuperApproveOperation")
public class SuperApproveOperation extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		
		PrintWriter out=response.getWriter();
		int rid=Integer.parseInt(request.getParameter("id"));
		int req=Integer.parseInt(request.getParameter("req"));
		String resp=(String)request.getParameter("resp");
		
		if(resp.equals("PENDING")) {
			
			LogicDao objDao=new LogicDao();
			try {
				LinkedHashMap<String,Integer> map=objDao.filledRemaining(req);
				
				int balance=map.get("rxnum100");
				int ans=map.get("rxans100");
				
				map.remove("rxnum100");
				map.remove("rxans100");
				
				if(ans==1) {
					NotifyTable note=new NotifyTable();
					note.insertNotification();
				}
				
				Set<String> set=map.keySet();
				
				Iterator<String> iter=set.iterator();
				
				
				while(iter.hasNext()) {
					ResourceDao rDao=new ResourceDao(ConnectionDao.getCon());
					String keyString=iter.next();
					rDao.updateForResource(keyString,map.get(keyString));
				}
				
				ProfileDao pDao=new ProfileDao(ConnectionDao.getCon());
				
				if(balance==0) {
				   pDao.changeResponseStatus(req,"APPROVED",rid);
				}else {
					pDao.changeResponseStatus(req-balance,"FILLED_PARTIALLY", rid);
				}
			}catch (Exception e) {
				out.print(e);
			}
			 response.sendRedirect("superadminview.jsp");
			
		}else if(resp.equals("FILLED_PARTIALLY")) {
			
			int resp_num=Integer.parseInt(request.getParameter("resp_num"));
			LogicDao objDao=new LogicDao();
			int val=req-resp_num;
			try {
				LinkedHashMap<String,Integer> map=objDao.filledRemaining(val);
				
				int balance=map.get("rxnum100");
				int ans=map.get("rxans100");
				
				map.remove("rxnum100");
				map.remove("rxans100");
				
				if(ans==1) {
					NotifyTable note=new NotifyTable();
					if(note.insertNotification()) {
						
					}
				}
				
				Set<String> set=map.keySet();
				
				Iterator<String> iter=set.iterator();
				
				
				while(iter.hasNext()) {
					ResourceDao rDao=new ResourceDao(ConnectionDao.getCon());
					String keyString=iter.next();
					rDao.updateForResource(keyString,map.get(keyString));
				}
				
				ProfileDao pDao=new ProfileDao(ConnectionDao.getCon());
				
				if(balance==0) {
				   pDao.changeResponseStatus(req,"APPROVED",rid);
				}else {
					pDao.changeResponseStatus((val-balance)+resp_num,"FILLED_PARTIALLY", rid);
				}
			}catch (Exception e) {
				out.print(e);
			}
			 response.sendRedirect("resourceview.jsp");
		}
		else {
			out.print("invalid processing");
		}
		
	}
}
