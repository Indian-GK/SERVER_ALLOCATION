package logics;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Stack;

import crudtest.*;
import viewer.Profile;

public class LogicDao {
	
	public LinkedHashMap<String,Integer> filledRemaining(int req){
		
		int num=req;
		int count=0;
		int total=0;
		LinkedHashMap<String,Integer> lMap=new LinkedHashMap<String, Integer>();
		
		String query="SELECT R_NAME,R_VALUE FROM RESOURCES";
		try(Connection con=ConnectionDao.getCon()){
			try(PreparedStatement ps=con.prepareStatement(query);
					ResultSet rs=ps.executeQuery()){
				
				while(rs.next()) {
					
					count+=1;
					
					if(num>0) {
					String key=rs.getString(1);
				    int value=rs.getInt(2);
				    
				    if(num>=value) {
				    	lMap.put(key,0);
				    	num-=value;
				    }else if(value>num) {
				    	lMap.put(key,value-num);
				    	num=0;
				    	
				    }
					}
					total+=rs.getInt(2);
				}
				lMap.put("rxnum100",num);
				int ans=total/count;
				if(ans<=10) {
					lMap.put("rxans100",1);
				}else {
					lMap.put("rxans100",0);
				}
			} catch (Exception e) {
				
			}
		}catch (Exception e) {
			
		}
		
		return lMap;
		
	}
	
	public List<Profile> getPartiallyFilled(){
	 	
	     List<Profile> ans = new ArrayList<>();
	     String query = "select * from RECORDS WHERE RESPONSE=? ORDER BY REQ_DATE LIMIT 1";
	     
	     try(Connection con=ConnectionDao.getCon()){
	     try(
	         PreparedStatement pt =con.prepareStatement(query);){
	    	 
	    	 pt.setString(1,"FILLED_PARTIALLY");
	    	 
	         ResultSet rs = pt.executeQuery();
	    	 
	    	 
	         
	         while(rs.next()){
	         	
	             int id = rs.getInt("C_ID");
	             int type = rs.getInt("USER_TYPE");
	             String reqDate = rs.getString("REQ_DATE");
	             int req = rs.getInt("REQUEST");
	             int num=rs.getInt("RESP_NUM");
	             String resp = rs.getString("RESPONSE");
	             String respDate=rs.getString("APP_DATE");
	             int rid=rs.getInt("R_ID");
	             
	             Profile row = new Profile(id,type,reqDate,req,num,resp,respDate,rid);
	             ans.add(row);
	         }
	         
	     }catch(Exception e){
	         e.printStackTrace();
	     }
	     }catch (Exception e) {
			
		}
	     return ans;
	 }
	
public int totalAvailable(){
		
		
		int count=0;
		
		String query="SELECT R_VALUE FROM RESOURCES";
		
		try(Connection con=ConnectionDao.getCon()){
			try(PreparedStatement ps=con.prepareStatement(query);
					ResultSet rs=ps.executeQuery()){
				
				while(rs.next()) {		
					count+=rs.getInt(1);
				}
				
			} catch (Exception e) {
				
			}
		}catch (Exception e) {
			
		}
		
		return count;
		
	}
	
}
